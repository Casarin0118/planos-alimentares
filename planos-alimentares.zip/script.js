function validarFormulario() {
    const form = document.getElementById('planoForm');
    const inputs = form.querySelectorAll('input[required]');
    let todosPreenchidos = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            todosPreenchidos = false;
            input.classList.add('is-invalid');
        } else {
            input.classList.remove('is-invalid');
        }
    });
    
    if (todosPreenchidos) {
        alert('Formulário válido!');
        window.location.href = "estilos.html";
    } else {
        alert('Por favor, preencha todos os campos obrigatórios.');
    }
}